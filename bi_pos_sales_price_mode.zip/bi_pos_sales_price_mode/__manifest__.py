{
    "name": "POS Sales Price Mode",
    "version": "17.0.0.1",
    "summary": """ POS Sales Price Mode""",
    "description": """POS Sales Price Mode""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Point Of Sale",
    "depends": ["point_of_sale"],
    "data": [
    ],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
    'assets': {
        'point_of_sale._assets_pos': [
            '/bi_pos_sales_price_mode/static/src/js/product_screen_custom.js',
        ]
    }
}
