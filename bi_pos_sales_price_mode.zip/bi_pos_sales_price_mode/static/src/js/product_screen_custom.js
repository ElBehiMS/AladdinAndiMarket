/** @odoo-module */

import { _t } from "@web/core/l10n/translation";
import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
import { Order } from "@point_of_sale/app/store/models";
import { patch } from "@web/core/utils/patch";
import { ProductCard } from "@point_of_sale/app/generic_components/product_card/product_card";

   patch(Order.prototype, {
   setup(_defaultObj, options) {
        super.setup(...arguments);
    },
    add_product(product, options) {
        super.add_product(...arguments);
        if (product.lst_price === 0.00) {
            this.pos.numpadMode = 'price';
        }
    }
    });
