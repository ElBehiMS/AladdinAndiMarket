/** @odoo-module */
import { CustomButtonPopup } from "@create_product_pos/js/create_product_bracode_pos";
import { _t } from "@web/core/l10n/translation";
import { ErrorBarcodePopup } from "@point_of_sale/app/barcode/error_popup/barcode_error_popup";
import { patch } from "@web/core/utils/patch";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { useService } from "@web/core/utils/hooks";

patch(ErrorBarcodePopup.prototype, {
    setup() {
        this.pos = usePos();
        this.popup = useService("popup");
    },
    
    async _CreateProductBarcode() {
        await this.popup.add(CustomButtonPopup, {
            title: _t("Create Product"),
        });
    }
})