/** @odoo-module */
import { AbstractAwaitablePopup } from "@point_of_sale/app/popup/abstract_awaitable_popup";
import { _t } from "@web/core/l10n/translation";
import { useService } from "@web/core/utils/hooks";

export class CustomButtonPopup extends AbstractAwaitablePopup {
    static template = "create_product_pos.CustomButtonPopup";
    static defaultProps = {
        closePopup: _t("Cancel"),
        confirmText: _t("Save"),
    };
    setup() {
        this.orm = useService("orm");
        this.notification = useService("notification");
    }
    async confirm() {
        let name = $("#display_name").val();
        let price = $("#list_price").val();
        let cost = $("#cost_price").val();
        let barcode = $("#barcode").val();
        let productType = $(".input-field").val();
        let detailedType = ''; 
        if (productType === 'storable') {
            detailedType = 'product'; 
        } else if (productType === 'consumable') {
            detailedType = 'consu';
        } else if (productType === 'service') {
            detailedType = 'service'; 
        }
        let values = {};
        if (name) {
            values["name"] = name;
        }
        if (cost) {
            values["standard_price"] = cost;
        }
        if (price) {
            values["lst_price"] = price;
        }
        if (barcode) {
            values["barcode"] = barcode;
        }
        if (detailedType) {
            console.log(detailedType,'detailedType')
            values["detailed_type"] = detailedType;
        }

        values["available_in_pos"] = true;
        const result = await this.orm.call("product.product", "create", [values]);
        if (result) {
            this.notification.add(_t("Product Created"));
            this.props.close();
        } else {
            this.notification.add(_t("Product Creation Failed"));
        }
    }
    
    
}