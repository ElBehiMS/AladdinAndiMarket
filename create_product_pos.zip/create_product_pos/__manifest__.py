{
    "name": "Create Product From POS Barcode",
    "summary": """
        Create Product From POS.""",
    "description": """
        Create Product From POS.
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Point of Sale",
    'version': '17.1',
    'depends': ['base', 'point_of_sale'],
    "data": [
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'create_product_pos/static/src/js/create_product_pos.js',
            'create_product_pos/static/src/js/create_product_bracode_pos.js',
            'create_product_pos/static/src/xml/barcode_error_popup.xml',
            'create_product_pos/static/src/xml/create_product_bracode_pos.xml',
        ],
    },
    "installable": True,
    "application": False,
}
