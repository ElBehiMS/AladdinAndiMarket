/** @odoo-module */
    import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
    import { patch } from "@web/core/utils/patch";

  patch(ProductScreen.prototype, {
   setup(_defaultObj, options) {
        super.setup(...arguments);
    },
    getNumpadButtons() {
        return [
            { value: "1" },
            { value: "2" },
            { value: "3" },
            { value: "quantity", text: "Qty" },
            { value: "4" },
            { value: "5" },
            { value: "6" },
            { value: "discount", text: "% Disc", disabled: !this.pos.config.manual_discount },
            { value: "7" },
            { value: "8" },
            { value: "9" },
            { value: "price", text: "Price", disabled: !this.pos.cashierHasPriceControlRights() },
            { value: "-", text: "+/-" },
            { value: "0" },
//            { value: this.env.services.localization.decimalPoint }, Replaced with '.00'
            { value: "$", text: ".00" },
            // Unicode: https://www.compart.com/en/unicode/U+232B
            { value: "Backspace", text: "⌫" },
        ].map((button) => ({
            ...button,
            class: this.pos.numpadMode === button.value ? "active border-primary" : "",
        }));
    },

    _setValue(val) {
        super._setValue(...arguments);
        const { numpadMode } = this.pos;
        const selectedLine = this.currentOrder.get_selected_orderline();
        if (selectedLine) {
            if (numpadMode === "price"){
            selectedLine.set_unit_price(val / 100);
            }
        }
    },

    onNumpadClick(buttonValue) {
    super.onNumpadClick(...arguments);
        if (buttonValue === '$' && this.currentOrder.get_selected_orderline() !== 'undefined') {
            this.currentOrder.get_selected_orderline().price = this.currentOrder.get_selected_orderline().price * 100
        }
    }

    });
