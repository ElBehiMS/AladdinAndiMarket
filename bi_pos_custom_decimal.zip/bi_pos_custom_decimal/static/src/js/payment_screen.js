/** @odoo-module */
    import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
    import { patch } from "@web/core/utils/patch";


   console.log("TASKING")
  patch(PaymentScreen.prototype, {
   setup(_defaultObj, options) {
        super.setup(...arguments);
    },
    updateOrderamount() {
        for (const paymentline of this.pos.get_order().paymentlines) {
            const paymentline_amount = paymentline.amount;
            const converted_payment_line_amount = paymentline.amount / 100
            paymentline.amount = converted_payment_line_amount
        }
    }
    });
