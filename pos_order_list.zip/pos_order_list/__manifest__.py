{
    "name": "Pos Order List",
    "summary": """
        Pos Order List.""",
    "description": """
        Pos Order List.
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Point of Sale",
    'version': '17.0.1.0.0',
    'depends': ['base', 'point_of_sale'],
    "data": [
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'pos_order_list/static/src/js/navbar.js',
            'pos_order_list/static/src/xml/navbar.xml',
            'pos_order_list/static/src/scss/navbar.scss',     
        ],
    },
    "installable": True,
    "application": False,
}
