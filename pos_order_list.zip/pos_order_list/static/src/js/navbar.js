/** @odoo-module **/

import { Navbar } from "@point_of_sale/app/navbar/navbar";
import { patch } from "@web/core/utils/patch";


patch(Navbar.prototype, {
    async _onClickOrders(order) {
        if (order) {
            this.pos.set_order(order);
        }
    },
    async _onClickNewOrder(){
        this.pos.add_new_order();
    },
    
    async _onClickDeleteOrders(){
        var order = this.pos.get_order();
        this.pos.removeOrder(order);
    }
})